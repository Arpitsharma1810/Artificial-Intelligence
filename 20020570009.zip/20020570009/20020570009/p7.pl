/*
Multiple of A & B

multi(+N1, +N2, -R)
    R is N1 * N2.
*/
multi(N1, N2, R) :- R is N1 * N2.